#!/bin/bash

if [ $# -eq 0 -o \
     $# -eq 1 -a "$1" = "-h" -o \
     \( $# -ne 2 -a $# -ne 3 \) ]; then
	printf "This script applies a set of kernel options to an existing .config.\n"
	printf "Usage:\n"
	printf "  apply-options.sh [options] config_seed_path kernel_source_path\n"
	printf "Options:\n"
	printf "  --override\n"
	printf "    All the kernel seed options are concatenated to the end of the existing\n"
	printf "    .config file, overriding previously set options to the new kernel seed value\n"
	printf "    if one is set.\n"
	printf "Example:\n"
	printf "  # cd /usr/src/linux\n"
	printf "  # make mrproper defconfig\n"
	printf "  # apply-options.sh --override /usr/src/kernel-seeds/3.14.25 .\n"
	
	echo "If you are not updating an existing .config then please run 'make mrproper defconfig' prior to running this script"
	exit 1
fi

TMP=/tmp/kernel-seeds.$$
mkdir "$TMP"

OVERRIDE=false
if [ $# -eq 3 -a "$1" = "--override" ]; then
	OVERRIDE=true
	shift
fi

CONFIG_SEED_PATH="$1"
KERNEL_SOURCE_PATH="$2"

if [ ! -d "$CONFIG_SEED_PATH" ]; then
	printf "apply-options.sh: The config_seed_path at \"$CONFIG_SEED_PATH\" is not accessible\n"
	exit 1
fi
if [ ! -d "$KERNEL_SOURCE_PATH" ]; then
	printf "apply-options.sh: The kernel_source_path at \"$KERNEL_SOURCE_PATH\" is not accessible\n"
	exit 1
fi
if [ ! -f "$KERNEL_SOURCE_PATH/.config" ]; then
	printf "apply-options.sh: Please run \"make defconfig\" to create a kernel .config file at \"$KERNEL_SOURCE_PATH/.config\"\n"
	exit 1
fi

find "$CONFIG_SEED_PATH" -name options -print0 | xargs -0 cat >> "$TMP"/seed.config
for OPTION in `cat "$TMP"/seed.config`; do
	# if the option is already set
	if grep "^"`echo "$OPTION" | sed -r 's/^(CONFIG.*?)=.*$/\1/'` "$KERNEL_SOURCE_PATH"/.config >/dev/null; then
		if $OVERRIDE; then
			echo "$OPTION"
			echo "$OPTION" >> "$TMP"/new.config
		fi
	else
		# the option is not set, so set it
		echo "$OPTION"
		echo "$OPTION" >> "$TMP"/new.config
	fi
done
cat "$TMP"/new.config >> "$KERNEL_SOURCE_PATH"/.config
pushd "$KERNEL_SOURCE_PATH"
	make olddefconfig
popd

rm -rf "$TMP"
