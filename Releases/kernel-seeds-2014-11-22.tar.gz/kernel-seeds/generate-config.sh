#!/bin/bash

if [ $# -ne 2 ]; then
	echo "Usage: $0 config_seed_path kernel_source_path"
	echo "If you are not updating an existing .config then please run 'make mrproper defconfig' prior to running this script"
	exit 1
fi

CONFIG_SEED_PATH="$1"
KERNEL_SOURCE_PATH="$2"

#pushd "$KERNEL_SOURCE_PATH"
#	make mrproper defconfig
#popd

find "$CONFIG_SEED_PATH" -name options -print0 | xargs -0 cat >> "$KERNEL_SOURCE_PATH"/.config

pushd "$KERNEL_SOURCE_PATH"
	make olddefconfig
popd
